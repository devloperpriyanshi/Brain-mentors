window.addEventListener("load", initEvents);

var audio;

function initEvents()
{
    audio = document.getElementById("audio");
    var ul = document.getElementById("songList");
    for(var i = 0; i < songsArray.length; i++)
    {
        var li = document.createElement("li");
        li.innerHTML = songsArray[i].songName;
        ul.appendChild(li);
        li.addEventListener("click", playSong);
    }
}

function playSong(evt)
{
    var songName = evt.srcElement.innerHTML;
    var songUrl;

    for(var i = 0; i < songsArray.length; i++)
    {
        if(songsArray[i].songName == songName)
        {
            songUrl = songsArray[i].songUrl;
        }
    }
    audio.src = songUrl;
    audio.play();
}