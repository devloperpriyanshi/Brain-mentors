var songsArray = [
    {
        // object- key:value
        "id" : 1,
        "songName" : 'Shape of you',
        "songUrl" : 'assets/songs/shapeofyou.mp3'
    },
    {
        "id" : 2,
        "songName" : 'Shape of you',
        "songUrl" : 'assets/songs/shapeofyou.mp3'
    },   
    {
        "id" : 3,
        "songName" : 'Shape of you',
        "songUrl" : 'assets/songs/shapeofyou.mp3'
    },
    {
        "id" : 4,
        "songName" : 'Shape of you',
        "songUrl" : 'assets/songs/shapeofyou.mp3'
    },
    {
        "id" : 5,
        "songName" : 'Shape of you',
        "songUrl" : 'assets/songs/shapeofyou.mp3'
    }
]