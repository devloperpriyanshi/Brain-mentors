window.addEventListener("load",initEvents);
var username;
var useremail;
var pswd;
var cpswd;
var span;

function initEvents() {
    username=document.querySelector("#username");
    useremail=document.querySelector("#useremail");
    pswd=document.querySelector("#pswd");
    cpswd=document.querySelector("#cpswd");
    span=document.querySelectorAll("span");
username.addEventListener("blur",validateUserName);
useremail.addEventListener("keyup",validateEmail);
    
}
function validateUserName() {
var text=username.value;
     text=text.trim();
     blankCheck(text,0);  //if user kept it as blank
}

function validateEmail() {
    var text = useremail.value;
    text=text.trim();
    blankCheck(text,1);    //if user kept it as blank

    var pattern=/([a-z|0-9]\w+[@]\w+[.]+[a-z]{2,3}$)/;
                 //validation after write 
                 var result = pattern.test(text);
                 console.log(result);
                 if (result) 
                 {
                 span[1].innerHTML="Valid email";
                   }  else {
                 span[1].innerHTML="Not Valid email";

}}

 function blankCheck(text,id) 
 {
     var text= username.value;
     text=text.trim();
     console.log("function executed");
     if (isEmpty(text)) {
         span[id].innerHTML = 'Please fill valid details';
     }
     else{
     span[id].innerHTML ='';

 }}

function isEmpty(text){
    return(text== null || text == undefined || text== "") ?true : false;

 }