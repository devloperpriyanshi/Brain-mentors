window.addEventListener("load", bindEvent)
var firstNum;
var secondNum;
var result=0;

function bindEvent() {
    firstNum=document.getElementById("f_num");
    secondNum=document.getElementById("s_num");

buttons=document.getElementsByTagName("button");
for(var i=0; i<buttons.length; i++)
{
    buttons[i]=document.addEventListener('click',calc)

}
}
function calc(evt){
    var opr= evt.srcElement.innerHTML;
     var expression = firstNum.value + opr + secondNum.value;
     var result = eval(expression);


document.getElementById("result").innerHTML=result;
}