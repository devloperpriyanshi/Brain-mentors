
$("button").on("click", function(){
   // $("h1").animate({opacity: 0.5});

   $("h1").slideUp().slideDown().animate({opacity: 0.5});

});


// $("button").on("click", function(){
//     // $("h1").slideUp();
//     // $("h1").slideDown();
//     $("h1").slideToggle();
// });


// $("button").on("click", function(){
//     // $("h1").fadeOut();
//     // $("h1").fadeIn();
//     $("h1").fadeToggle();
// });

// $("button").on("click", function(){
//     // $("h1").hide();
//     // $("h1").show();
//     $("h1").toggle();
// });

// $("button").remove();

// $("h1").before("<button>New</button>");
// $("h1").after("<button>New</button>");
// $("h1").prepend("<button>New</button>");
// $("h1").append("<button>New</button>");


// $("h1").on("click", function() {
//     $("h1").css("color", "purple");
// });

// $("h1").on("mouseover", function() {
//     $("h1").css("color", "purple");
// });

// $("input").keypress(function(event) {
//     console.log(event.key);
// })

// Javascript Syntax
// for(var i = 0; i <= 5; i++)
// {
//     document.querySelectorAll("button")[i].addEventListener("click", function() {
//         document.querySelector("h1").style.color = "purple";
//     });
// }

// JQuery Syntax
// $("button").click(function() {
//     $("h1").css("color", "purple");
// });

// $(document).ready(function() {
//      $("h1").css("color", "red");
//  });

// console.log($("h1").css("color", "red"));

// $("h1").css("font-size", "100px");

// $("h1").addClass("big-title");

// $("h1").text("Bye");

// // $("button").text("Don't Click Me");

// $("button").html("Hey");

// console.log("img").attr("src", "play.png");

// $("a").attr("href", "https://www.jquery.com");

// $("h1").click(function() {
//     $("h1").css("color", "purple");
// })