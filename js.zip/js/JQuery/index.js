// $(document).ready(function() {
//      $("h1").css("color", "red");
//  });

// console.log($("h1").css("color", "red"));

// $("h1").css("font-size", "100px");

// $("h1").addClass("big-title");

// $("h1").text("Bye");

// // $("button").text("Don't Click Me");

// $("button").html("Hey");

// console.log("img").attr("src", "play.png");

// $("a").attr("href", "https://www.jquery.com");

$("h1").click(function() {
    $("h1").css("color", "purple");
})